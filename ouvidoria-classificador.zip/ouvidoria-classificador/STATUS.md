# STATUS do Projeto — Classificador Ouvidoria

> Memória entre sessões. O agente DEVE atualizar este arquivo ao concluir qualquer
> entrega: o que foi feito, decisões tomadas, pendências e próximos passos.

## Fase atual
Fase 0 — repositório inicializado com specs. Nenhuma fase de implementação iniciada.

## Checklist de fases (ver AGENTS.md)
- [ ] Fase 1 — Fundação de dados (DDLs + loader + testes)  -> docs/02
- [ ] Fase 2 — Enriquecimento e indexação                  -> docs/03
- [ ] Fase 3 — Retrieval + gate recall@K                   -> docs/03
- [ ] Fase 4 — Inferência (prompt + schema + endpoint)     -> docs/04
- [ ] Fase 5 — Pós-processamento e roteamento              -> docs/05
- [ ] Fase 6 — Golden set e avaliação                      -> docs/05

## Decisões registradas
- (data) — decisão — motivo

## Pendências / bloqueios
- Preencher nomes físicos reais em config/columns.dev.yaml (marcados com AJUSTAR).
- Definir catálogo/schema reais em config/pipeline.yaml.
- Definir nomes reais dos endpoints de Model Serving em config/pipeline.yaml.
