# Classificador de Manifestações — Ouvidoria Bancária

Sistema de classificação de manifestações de clientes (texto livre) em uma taxonomia
hierárquica Família > Produto > Assunto (~3.000 combinações válidas), da qual derivam
dois alvos prioritários: **Gestor Nível Um** (função da Família) e **Tema** (função da
tripla exata F+P+A). Stack: Databricks (Unity Catalog, Vector Search, Model Serving
com Qwen3-Embedding para embeddings e Llama 8B para inferência few-shot).

## REGRAS DE OURO (invioláveis — valem para todo código gerado neste repo)

1. **Predição única = folha da árvore.** O modelo prevê somente `id_folha` (uma das
   ~3.000 combinações válidas). Gestor e Tema são SEMPRE derivados por lookup na
   tabela `taxonomia_canonica`. Nunca prever Tema ou Gestor de forma independente.
2. **Classificação é SELEÇÃO, nunca geração.** O LLM escolhe um `id_folha` de um
   enum fechado (shortlist do retrieval). Jamais gerar nomes de categoria como texto
   livre. Isso garante zero combinações FPA inexistentes por construção.
3. **Nomes físicos de coluna só existem em `src/io/loader.py`**, traduzidos via
   `config/columns.{env}.yaml` para o schema lógico interno. Nenhum outro módulo
   pode referenciar nomes físicos de tabelas ou colunas.
4. **Features externas só via `feature_registry`** (tabela Delta). Nunca hardcoded
   em prompt, código ou schema. O enum de `dados_faltantes` do JSON Schema é gerado
   em runtime a partir do registry (`WHERE ativa = true`).
5. **O modelo pode se abster.** O output tem `status` com valores AUTO |
   REQUER_CONSULTA_SISTEMA | REVISAO_HUMANA. Nunca forçar escolha entre candidatos
   de Temas diferentes cuja distinção dependa de dados de sistema.
6. **PII é mascarada antes** de qualquer embedding ou chamada a LLM (CPF, conta,
   agência, telefone, nomes próprios).
7. **Structured outputs sempre** (`response_format: json_schema` no endpoint), com
   `id_folha` restrito por enum à shortlist. Temperatura 0.
8. **Toda mudança de configuração ou código roda o golden set** (`tests/golden_set/`)
   antes de merge/publicação. Isso inclui INSERTs/UPDATEs nas tabelas de config.
9. **Prompts são templates Jinja2 versionados** (`prompts/`), registrados no MLflow
   Prompt Registry. Nada de prompt montado por concatenação ad-hoc espalhada.
10. **Batch scoring via `ai_query()`** em SQL/DLT sobre coluna de prompt pré-montado.

## MAPA DO REPO — leia o doc certo antes de codar cada parte

| Vai trabalhar em...                     | Leia primeiro                  |
|-----------------------------------------|--------------------------------|
| Visão geral / decisões de arquitetura   | `docs/01_arquitetura.md`       |
| Tabelas de config (DDL), loader, YAML   | `docs/02_dados_config.md`      |
| Embeddings, índices, busca, recall@K    | `docs/03_retrieval.md`         |
| Prompt, JSON Schema, few-shot, LLM      | `docs/04_inferencia.md`        |
| Roteamento, confiança, métricas, eval   | `docs/05_roteamento_eval.md`   |

Artefatos prontos para copiar (não reinventar): `config/columns.dev.yaml`,
`config/pipeline.yaml`, `prompts/inferencia_v1.j2`.

## FASES DE IMPLEMENTAÇÃO (uma por sessão; não pule etapas)

1. **Fundação de dados**: DDLs das 4 tabelas de config no Unity Catalog + loader
   com columns.yaml + testes de schema. → `docs/02_dados_config.md`
2. **Enriquecimento e indexação**: geração offline das descrições enriquecidas por
   folha + criação dos 2 índices no Vector Search. → `docs/03_retrieval.md`
3. **Retrieval**: busca híbrida (denso+lexical), merge/dedup, rerank opcional,
   job de medição de recall@K (gate ≥ 98%). → `docs/03_retrieval.md`
4. **Inferência**: montagem do prompt Jinja2 + JSON Schema dinâmico + chamada ao
   endpoint Llama 8B + parsing defensivo. → `docs/04_inferencia.md`
5. **Pós-processamento e roteamento**: lookup gestor/tema, sinais de confiança,
   decisão AUTO/REVISAO/CONSULTA. → `docs/05_roteamento_eval.md`
6. **Avaliação**: golden set, métricas em 4 níveis, curva risco-cobertura,
   job de regressão. → `docs/05_roteamento_eval.md`

## CONVENÇÕES DE TRABALHO

- **Toda avaliação é um run do MLflow** (experimento em `config/pipeline.yaml`):
  params + métricas dos 4 níveis + artifacts. Mudança só é promovida após comparar
  com o run baseline. Detalhe em `docs/05_roteamento_eval.md` §3b.
- **Estilo de código**: seguir a skill `estilo-codigo`
  (`assistant-skill/estilo-codigo/SKILL.md`) em todo código gerado — comentários
  breves em minúsculo, zero emojis em código/prints/logs, código simples sem
  over-engineering, nomes em português snake_case.
- Ao concluir qualquer fase (ou parte dela), **atualize `STATUS.md`** com o que foi
  feito, decisões tomadas e pendências. É a memória entre sessões.
- Código em Python (PySpark onde couber), notebooks só como orquestração fina;
  lógica reutilizável vai para `src/`.
- Todo notebook/job criado deve ser idempotente (re-execução segura).
- Nomes de objetos no Unity Catalog: catálogo/schema definidos em
  `config/pipeline.yaml` — nunca hardcoded.
