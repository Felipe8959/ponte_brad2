# Golden set de regressão (ver docs/05_roteamento_eval.md §4)

Formato: JSONL, um caso por linha. Meta: 300-500 casos cobrindo fáceis por família,
cauda longa, pares ambíguos (resposta esperada = abstenção), PII, textos ruidosos.
`seed_casos.jsonl` contém exemplos do formato — substituir por casos reais.
Rodar automaticamente sempre que código OU configuração (tabelas Delta) mudar.
