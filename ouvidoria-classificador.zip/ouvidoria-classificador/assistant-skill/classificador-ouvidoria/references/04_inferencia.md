# 04 — Inferência LLM (Few-Shot + Structured Outputs)

> **Contexto**: etapa que recebe a shortlist do retrieval (doc 03) e decide a folha —
> ou se abstém. Modelo: Llama 8B via Model Serving, temperatura 0, structured
> outputs. O prompt é montado em runtime a partir do template Jinja2 + tabelas de
> config. Nada de conteúdo dinâmico hardcoded no template.

## 1. Seleção dinâmica de few-shot (dois critérios combinados)

1. **Cobertura balanceada da shortlist**: para cada Tema representado nos
   candidatos, recuperar 1–2 exemplares de `idx_exemplares` mais próximos do texto
   de entrada. (Se pegar só os N globalmente mais similares, os exemplos ficam
   todos do mesmo Tema e enviesam a escolha.)
2. **Pares contrastivos**: se a shortlist contém um par ativo do
   `contrato_desambiguacao`, injetar um exemplo de cada lado do par **e um exemplo
   de abstenção** (`eh_abstencao = true`, saída REQUER_CONSULTA_SISTEMA). Ensinar
   o modelo a se abster exige mostrar abstenção nos exemplos.

Limite p/ Llama 8B: **3–5 exemplos no total**, sempre ≥ 1 de abstenção quando
houver par ambíguo na shortlist. Implementar em `src/inference/fewshot.py`.

## 2. Montagem do prompt

Template: `prompts/inferencia_v1.j2` (pronto no repo — usar como está; mudanças
geram `inferencia_v2.j2` + registro no MLflow Prompt Registry). Variáveis:

| Variável | Fonte |
|---|---|
| `features_ativas` | `feature_registry WHERE ativa` |
| `dados_cliente` | `src/enrich/features.py` (só `integrada_online = true`) |
| `shortlist` | retrieval (doc 03), com id, F>P>A, tema, descricao_curta |
| `few_shot` | seção 1 acima |
| `texto_mascarado` | pré-processamento (doc 03 §1) |

Logar por predição: versão do template, `versao_taxonomia`, snapshot da shortlist,
IDs dos exemplares usados. Auditoria completa via MLflow.

## 3. JSON Schema dinâmico

Gerado em runtime por `src/inference/schema.py`:
- enum de `id_folha` e `candidatos_plausiveis` ← IDs da shortlist do caso;
- enum de `dados_faltantes` ← `feature_registry WHERE ativa` (+ 'NENHUM').

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["raciocinio", "status", "id_folha",
               "candidatos_plausiveis", "dados_faltantes", "confianca"],
  "properties": {
    "raciocinio": { "type": "string", "maxLength": 300 },
    "status": { "enum": ["AUTO", "REQUER_CONSULTA_SISTEMA", "REVISAO_HUMANA"] },
    "id_folha": {
      "anyOf": [ { "enum": ["<IDS_DA_SHORTLIST>"] }, { "type": "null" } ]
    },
    "candidatos_plausiveis": {
      "type": "array", "items": { "enum": ["<IDS_DA_SHORTLIST>"] }
    },
    "dados_faltantes": {
      "type": "array", "items": { "enum": ["<FEATURES_ATIVAS>", "NENHUM"] }
    },
    "confianca": { "enum": ["ALTA", "MEDIA", "BAIXA"] }
  }
}
```

Detalhes que importam:
- `raciocinio` vem **antes** de `id_folha` no schema — ordem de geração importa;
  o modelo decide melhor depois de raciocinar. `maxLength` curto (8B divaga).
- `confianca` autodeclarada é apenas UM sinal entre vários no roteamento (doc 05),
  nunca critério único — autoavaliação de LLM é mal calibrada.
- Invariantes a validar no parsing defensivo (`src/inference/parse.py`):
  `status = AUTO` ⇒ `id_folha` não nulo; `status = REQUER_CONSULTA_SISTEMA` ⇒
  `id_folha` nulo, `candidatos_plausiveis` ≥ 2 e `dados_faltantes` ≠ ['NENHUM'].
  Violação de invariante ⇒ rotear para REVISAO_HUMANA e logar (nunca deve ocorrer
  com decoding restrito; se ocorrer, é bug a investigar).

## 4. Chamada ao endpoint (Model Serving / Foundation Model API)

```python
payload = {
  "messages": [
    {"role": "system", "content": prompt_system},   # regras fixas do template
    {"role": "user",   "content": prompt_user},     # candidatos + exemplos + entrada
  ],
  "temperature": 0,
  "response_format": {
    "type": "json_schema",
    "json_schema": {"name": "classificacao_ouvidoria", "schema": schema_dinamico,
                     "strict": True}
  },
}
```

O decoding restrito do `response_format` garante o enum — é a materialização da
regra "seleção, nunca geração".

### Limites do Llama 8B (respeitar; não "resolver" aumentando contexto)
- Shortlist: 8–12 candidatos, `descricao_curta` de 1 linha cada.
- Few-shot: 3–5 exemplos.
- Se a meta de qualidade não for atingida no tier difícil, o plano é trocar o
  endpoint por Llama 70B **apenas nesse tier** (config em `pipeline.yaml`), não
  inflar o prompt do 8B.

## 5. Batch scoring

Para histórico e cargas diárias: montar a coluna de prompt via pipeline Spark e
chamar `ai_query()` em SQL/DLT sobre ela (paralelização nativa). Online/near-real-
time: chamada direta ao endpoint via `src/inference/client.py`. Mesmo template,
mesmo schema — um único caminho de montagem de prompt para os dois modos.
