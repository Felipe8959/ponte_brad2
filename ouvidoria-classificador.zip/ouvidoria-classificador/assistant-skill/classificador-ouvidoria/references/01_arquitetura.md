# 01 — Arquitetura Geral

> **Contexto**: classificador de manifestações de Ouvidoria bancária. Entrada: texto
> livre do cliente (único dado disponível hoje). Saída: folha da taxonomia
> Família > Produto > Assunto (~3.000 combinações), da qual derivam Gestor Nível Um
> e Tema. Este doc define as decisões estruturais; os demais docs detalham cada etapa.

## 1. Decisão central: um único alvo de predição

- `Gestor Nível Um` = f(Família) e `Tema` = f(Família, Produto, Assunto) são
  **funções determinísticas**. Portanto o sistema prevê apenas `id_folha`
  (ID canônico de uma combinação FPA válida) e deriva o resto por lookup.
- Prever Tema/Gestor de forma independente criaria risco de inconsistência interna
  (Tema incompatível com a FPA prevista) — erro pior que uma classificação errada,
  pois destrói a confiança do analista.
- **Classificação é seleção, nunca geração**: o LLM escolhe um `id_folha` de uma
  lista fechada (enum no JSON Schema). Zero combinações inválidas por construção.
  Não existe "pós-validação corretiva" porque não existe saída inválida possível
  (mantém-se validação defensiva de schema, que nunca deve disparar).

## 2. Por que não as alternativas

| Opção | Veredito |
|---|---|
| Cascata F→P→A (3 chamadas) | Propaga erro; ambiguidade real mora no nível 3, onde a cascata chega com menos contexto. Hierarquia é estrutura de dados, não pipeline de inferência. |
| Retrieval semântico puro (top-1) | Labels curtos têm semântica pobre; não resolve pares ambíguos. Vira a camada de **geração de candidatos** (doc 03). |
| Tema direto + mapeamento reverso p/ FPA | Mal-posto (1 Tema → N triplas). Reaproveitado como **sinal auxiliar de concordância** no roteamento (doc 05). |
| **RAG taxonômico + constrained/structured output** | **Arquitetura adotada** (detalhada abaixo). |

## 3. Ambiguidade intrínseca (texto sozinho não decide)

- Nomeação técnica: **incerteza aleatória** — em vários casos (renegociação, cartão,
  saldo) o analista humano consulta sistemas internos para decidir. O texto não
  contém a informação; nenhum modelo supera o erro de Bayes do canal texto-apenas.
- Consequência: o objetivo do sistema NÃO é acertar sempre; é **distinguir o que é
  decidível pelo texto do que não é** e tratar cada caso de forma diferente.
- Instrumentos (detalhados nos docs 02 e 05):
  - **Matriz de confusão no nível de Tema** sobre baseline texto-apenas → clusters
    de confusão mútua/simétrica = "classes de ambiguidade". Sinais adicionais:
    reclassificações históricas do analista e discordância entre analistas.
  - **Contrato de desambiguação** (tabela `contrato_desambiguacao`): para cada par
    ambíguo, qual feature de sistema decide e por qual regra. Vira backlog
    priorizado de integração de dados.
  - **Válvula de escape no schema**: status `REQUER_CONSULTA_SISTEMA` + conjunto de
    candidatos plausíveis + `dados_faltantes` (enum do feature_registry).
  - **Não penalizar o irrecuperável**: em fine-tuning/calibração, casos de classe
    ambígua têm como resposta correta o conjunto + abstenção, não o rótulo final
    que o humano só obteve com dados de sistema.

## 4. Pipeline end-to-end (7 passos)

```
texto bruto
  → [1] pré-processamento (normalização leve + máscara de PII)
  → [2] dois índices vetoriais: labels (descrições enriquecidas das 3.000 folhas)
        + exemplares (histórico rotulado)                       → doc 03
  → [3] geração de candidatos: top-K híbrido (denso+BM25) de cada índice,
        merge/dedup por id_folha, rerank opcional; K final 8–25;
        GATE: recall@K ≥ 98–99% (teto do sistema, monitorado)   → doc 03
  → [4] few-shot dinâmico: 1–2 exemplares por Tema da shortlist +
        pares contrastivos p/ ambiguidades conhecidas
        (incluindo exemplo de abstenção)                        → doc 04
  → [5] inferência LLM (Llama 8B, temperatura 0, structured output;
        id_folha ∈ enum da shortlist)                           → doc 04
  → [6] pós-processamento determinístico: lookup id_folha → (F, P, A,
        Gestor, Tema); roteamento AUTO | REVISAO_HUMANA |
        REQUER_CONSULTA_SISTEMA                                 → doc 05
  → [7] loop de feedback: revisões humanas viram exemplares novos
        (com carência), recalibração mensal de limiares, matriz de
        confusão atualizada p/ descobrir novas ambiguidades     → doc 05
```

## 5. Dois estágios (custo/latência)

- **Estágio A (barato)**: kNN sobre índice de exemplares e/ou encoder leve
  fine-tunado em PT-BR (ex.: BERTimbau / e5-multilingual) resolve os casos fáceis
  com margem alta (~70% do volume) sem chamar o LLM.
- **Estágio B (LLM)**: só o terço difícil passa pelo pipeline completo.
- A avaliação deve permitir trocar o endpoint do estágio B (Llama 8B → 70B) apenas
  no tier difícil, se o 8B não bater a meta.

## 6. Princípio de configuração

**Tudo que muda vira dado** (tabelas Delta versionadas / YAML): taxonomia,
exemplares, contrato de desambiguação, feature_registry, mapeamento de colunas.
Só regras verdadeiramente imutáveis vivem no template de prompt. Prompt final é
montado em runtime (Jinja2). Delta time travel responde "por que classificou assim
em DD/MM?" reconstruindo a config vigente na data — requisito de setor regulado.
