# 02 — Dados de Configuração (Unity Catalog)

> **Contexto**: este doc define as tabelas Delta que parametrizam todo o sistema
> (taxonomia, features externas, ambiguidades, exemplares) e a camada de tradução de
> nomes de colunas. Regra de ouro: tudo que muda é dado; nenhum módulo fora de
> `src/io/loader.py` conhece nomes físicos de tabelas/colunas.

Catálogo/schema alvo definidos em `config/pipeline.yaml` (placeholder abaixo:
`ouvidoria.config`). Ajustar via config, nunca no DDL hardcoded em produção.

## 1. `taxonomia_canonica` — fonte de verdade da árvore

```sql
CREATE TABLE IF NOT EXISTS ouvidoria.config.taxonomia_canonica (
  id_folha              STRING NOT NULL,   -- ex.: 'F0412' (imutável entre versões)
  familia               STRING NOT NULL,
  produto               STRING NOT NULL,
  assunto               STRING NOT NULL,
  gestor_nivel_um       STRING NOT NULL,   -- derivado da familia (redundância p/ lookup direto)
  tema_classificacao    STRING NOT NULL,   -- derivado da tripla exata (F,P,A)
  descricao_enriquecida STRING,            -- glossário gerado offline por LLM (doc 03)
  descricao_curta       STRING,            -- 1 linha, usada no prompt de inferência
  palavras_chave        ARRAY<STRING>,     -- termos lexicais p/ busca híbrida/BM25
  ativa                 BOOLEAN NOT NULL DEFAULT true,
  versao_taxonomia      STRING NOT NULL,   -- ex.: 'v2026.1'
  atualizado_em         TIMESTAMP,
  CONSTRAINT pk_taxonomia PRIMARY KEY (id_folha)
) COMMENT 'Tabela canônica: 1 linha por combinação FPA válida (~3.000). Gestor e Tema derivam daqui por lookup.';
```

Regras:
- Unicidade lógica de (familia, produto, assunto) — validar em teste, além da PK.
- Mudança de `versao_taxonomia` → invalida e reindexa embeddings (doc 03).
- `id_folha` nunca é reciclado; folhas descontinuadas ficam `ativa = false`.

## 2. `feature_registry` — extensibilidade das consultas externas

Dois estados independentes por feature: **existir como conceito** (`ativa` → o
modelo pode apontá-la como faltante; entra no enum `dados_faltantes` do JSON Schema)
e **estar integrada** (`integrada_online` → o valor real é consultado e entra no
prompt como fato).

```sql
CREATE TABLE IF NOT EXISTS ouvidoria.config.feature_registry (
  feature_id           STRING NOT NULL,    -- ex.: 'POSSUI_CARTAO_ATIVO' (UPPER_SNAKE)
  descricao_para_llm   STRING NOT NULL,    -- frase curta usada no prompt
  tipo                 STRING NOT NULL,    -- 'boolean' | 'numeric' | 'categorical' | 'text'
  ativa                BOOLEAN NOT NULL DEFAULT true,
  integrada_online     BOOLEAN NOT NULL DEFAULT false,
  fonte_dados          STRING,             -- sistema de origem quando integrada (documentacional)
  temas_relacionados   ARRAY<STRING>,
  criado_em            TIMESTAMP,
  atualizado_em        TIMESTAMP,
  CONSTRAINT pk_feature PRIMARY KEY (feature_id)
) COMMENT 'Registro declarativo de dados de sistema que desambiguam Temas. Adicionar feature nova = 1 INSERT, zero deploy.';
```

Seed inicial (exemplos citados pelo negócio — ajustar):

```sql
INSERT INTO ouvidoria.config.feature_registry
  (feature_id, descricao_para_llm, tipo, ativa, integrada_online, temas_relacionados, criado_em)
VALUES
  ('POSSUI_CARTAO_ATIVO',         'Se o cliente possui cartão de crédito ativo',          'boolean', true, false, array('Tarifas e Encargos','Fraude e Contestação'), current_timestamp()),
  ('ACORDO_RENEGOCIACAO_VIGENTE', 'Se o cliente possui acordo de renegociação vigente',   'boolean', true, false, array('Renegociação','Cobrança'),                    current_timestamp()),
  ('DIVIDA_EM_ABERTO',            'Se o cliente possui dívida em aberto e o valor',       'numeric', true, false, array('Cobrança','Renegociação'),                    current_timestamp()),
  ('FATURA_CARTAO',               'Itens da última fatura do cartão do cliente',          'text',    true, false, array('Tarifas e Encargos','Fraude e Contestação'), current_timestamp());
```

Comportamento em runtime (implementar em `src/enrich/features.py`):
1. `SELECT feature_id, descricao_para_llm FROM feature_registry WHERE ativa` →
   gera o enum de `dados_faltantes` do JSON Schema **e** a seção do prompt
   "[DADOS DE SISTEMA QUE PODEM SER CONSULTADOS]".
2. Para features `integrada_online = true`: o passo de enriquecimento consulta o
   valor real e injeta no prompt como "[DADOS DO CLIENTE JÁ CONSULTADOS]". Pares
   ambíguos cobertos migram automaticamente de REQUER_CONSULTA_SISTEMA para
   resolução automática — sem tocar no pipeline.

## 3. `contrato_desambiguacao` — pares de Temas que o texto não separa

```sql
CREATE TABLE IF NOT EXISTS ouvidoria.config.contrato_desambiguacao (
  id_contrato          STRING NOT NULL,
  tema_a               STRING NOT NULL,
  tema_b               STRING NOT NULL,
  features_decisorias  ARRAY<STRING> NOT NULL,  -- FKs lógicas p/ feature_registry
  regra_decisao        STRING,                  -- ex.: 'se ACORDO_RENEGOCIACAO_VIGENTE=true -> tema_a'
  origem               STRING,                  -- 'matriz_confusao' | 'reclassificacao_historica' | 'especialista'
  volume_estimado_mensal INT,                   -- p/ priorizar backlog de integração
  ativa                BOOLEAN NOT NULL DEFAULT true,
  atualizado_em        TIMESTAMP,
  CONSTRAINT pk_contrato PRIMARY KEY (id_contrato)
) COMMENT 'Pares de Temas indistinguíveis por texto + feature de sistema que decide. Alimenta roteamento determinístico (doc 05).';
```

Uso no roteamento (doc 05): se os top candidatos da shortlist caem num par ativo
deste contrato **e** as features decisórias não estão integradas/populadas →
rotear direto para REQUER_CONSULTA_SISTEMA, sem depender da confiança do modelo.

## 4. `exemplares_rotulados` — base do few-shot e do kNN

```sql
CREATE TABLE IF NOT EXISTS ouvidoria.config.exemplares_rotulados (
  id_exemplar          STRING NOT NULL,
  texto_mascarado      STRING NOT NULL,        -- PII já removida (nunca armazenar cru aqui)
  id_folha             STRING NOT NULL,        -- FK lógica p/ taxonomia_canonica
  saida_json           STRING NOT NULL,        -- output esperado completo (inclui exemplos de abstenção!)
  eh_abstencao         BOOLEAN NOT NULL DEFAULT false, -- true quando saida = REQUER_CONSULTA_SISTEMA
  origem               STRING,                 -- 'historico' | 'revisao_humana' | 'sintetico'
  qualidade_verificada BOOLEAN NOT NULL DEFAULT false,
  data_carencia_fim    DATE,                   -- exemplar de feedback só entra no índice após carência
  versao_taxonomia     STRING NOT NULL,
  criado_em            TIMESTAMP,
  CONSTRAINT pk_exemplar PRIMARY KEY (id_exemplar)
) COMMENT 'Exemplares p/ índice kNN e few-shot dinâmico. Deduplicados, estratificados p/ cobrir cauda longa.';
```

Regras: deduplicar por similaridade; amostragem estratificada por folha (cauda
longa das 3.000); exemplares vindos de revisão humana só entram no índice após
`qualidade_verificada = true` e fim da carência.

## 5. Mapeamento de colunas — `config/columns.{env}.yaml`

Arquivo pronto em `config/columns.dev.yaml` (copiar/ajustar por ambiente).
Padrão do loader — **único lugar do repo que vê nomes físicos**:

```python
# src/io/loader.py
import yaml
from pyspark.sql import functions as F

def _cfg(env: str) -> dict:
    with open(f"config/columns.{env}.yaml") as f:
        return yaml.safe_load(f)

def carregar(nome_logico: str, env: str = "dev"):
    t = _cfg(env)["tabelas"][nome_logico]
    df = spark.table(t["nome_fisico"])
    return df.select(*[F.col(fis).alias(log) for log, fis in t["colunas"].items()])
```

A partir do loader, 100% do pipeline só conhece nomes lógicos (`texto`, `familia`,
`tema`, ...). Trocar base de origem = editar YAML, zero mudança de código.

## 6. Testes obrigatórios desta fase

- Schema de cada tabela confere com o DDL (nomes, tipos, constraints).
- (familia, produto, assunto) único em `taxonomia_canonica`.
- Todo `features_decisorias[i]` do contrato existe no `feature_registry`.
- Todo `id_folha` de `exemplares_rotulados` existe e está `ativa` na taxonomia.
- Loader traduz corretamente um YAML de exemplo (teste com tabela fake).
