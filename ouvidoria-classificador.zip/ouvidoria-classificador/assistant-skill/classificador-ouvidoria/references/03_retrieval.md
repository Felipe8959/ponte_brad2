# 03 — Enriquecimento, Indexação e Retrieval

> **Contexto**: etapa que transforma o problema de "3.000 classes" em "escolher entre
> 8–25 candidatos". A qualidade daqui define o teto do sistema: se a folha correta
> não está na shortlist, o LLM não tem como recuperar. Gate: recall@K ≥ 98–99%.

## 1. Pré-processamento do texto (antes de qualquer embedding/LLM)

- Normalização **leve** (espaços, encoding). NÃO corrigir agressivamente: erros de
  digitação do cliente carregam sinal.
- **Máscara de PII obrigatória**: CPF, conta, agência, cartão, telefone, e-mail,
  nomes próprios → tokens `<CPF>`, `<CONTA>`, etc. Além de LGPD, melhora embeddings
  (números de conta são ruído vetorial). Implementar em `src/preprocess/pii.py`
  com regex + NER PT-BR; testar com casos no golden set.

## 2. Descrições enriquecidas (job offline, uma vez por versão de taxonomia)

Labels curtos ("Cobrança > Tarifa > Contestação") têm semântica pobre para
embedding. Job offline usa LLM para gerar, por folha:
- `descricao_enriquecida`: definição de 2–4 frases + **3–5 frases típicas de
  cliente** que caem naquela folha (linguagem coloquial, com gírias/erros comuns);
- `descricao_curta`: 1 linha para o prompt de inferência;
- `palavras_chave`: termos lexicais (nomes de produto, jargão) p/ BM25.

Gravar na `taxonomia_canonica`. Revisão amostral humana antes de indexar.
Mudou `versao_taxonomia` → regenerar e reindexar.

## 3. Dois índices no Databricks Vector Search

| Índice | Conteúdo do embedding | Responde |
|---|---|---|
| `idx_labels` | `descricao_enriquecida` (concatenação F+P+A + glossário) de cada folha ativa | "que categorias este texto parece descrever?" |
| `idx_exemplares` | `texto_mascarado` dos exemplares rotulados | "que casos parecidos já vimos e como foram classificados?" (kNN — costuma ser o sinal mais forte) |

- Embedding **concatenado com hierarquia** no índice de labels (contexto F+P
  desambigua assuntos homônimos entre produtos, ex.: "Anuidade" existe sob vários
  produtos). Embeddings isolados por nível só serviriam para cascata (descartada).
- **Self-managed embeddings**: computar vetores via endpoint Qwen3 e gravar coluna
  de vetor na tabela Delta; o índice do Vector Search sincroniza a partir dela.

## 4. Qwen3-Embedding — uso correto (instruction-aware)

O Qwen3-Embedding espera **instrução no lado da query** e **texto puro no lado do
documento**. Inconsistência entre indexação e busca degrada recall silenciosamente.

```python
INSTRUCAO_QUERY = ("Instruct: Dado o relato de um cliente bancário, recupere as "
                   "categorias de classificação de Ouvidoria correspondentes\nQuery: ")

def embed_query(texto_mascarado: str) -> list[float]:
    return chamar_endpoint_embedding(INSTRUCAO_QUERY + texto_mascarado)

def embed_documento(descricao: str) -> list[float]:
    return chamar_endpoint_embedding(descricao)  # SEM instrução
```

Regra: `embed_documento` na indexação (labels e exemplares); `embed_query` na
busca. Centralizar em `src/retrieval/embeddings.py` — proibido chamar o endpoint
de embedding fora desse módulo.

## 5. Busca híbrida e geração da shortlist

1. **Denso**: top-K de `idx_labels` e de `idx_exemplares` (query embeddada com
   instrução).
2. **Lexical (BM25/keyword)**: match contra `palavras_chave` e texto das
   descrições — jargão bancário e nomes próprios de produto ("Consignado INSS",
   "Crediário X") são fortemente lexicais. Vector Search híbrido do Databricks ou
   camada BM25 própria.
3. **Merge + dedup por `id_folha`** (exemplares votam na folha do seu rótulo),
   com score combinado (ex.: RRF — reciprocal rank fusion).
4. **Rerank opcional** com cross-encoder se recall@K exigir.
5. **K final: 8–12** (limite prático do Llama 8B — doc 04). Compensar K menor com
   qualidade do rerank, não aumentando K.

Parâmetros (K por índice, K final, pesos do fusion, uso de rerank) em
`config/pipeline.yaml` — nunca hardcoded.

## 6. Gate de qualidade: recall@K

- Job `notebooks/eval_recall.py`: sobre conjunto rotulado de validação, medir % de
  casos em que a folha correta está na shortlist final.
- **Meta: ≥ 98–99%.** Abaixo disso, ajustar (descrições, pesos, K, rerank) antes
  de qualquer trabalho no LLM — é o teto do sistema.
- Monitorar continuamente em produção (proxy: posição do rótulo confirmado pelo
  humano dentro da shortlist registrada no log).

## 7. Estágio A barato (antes do LLM)

kNN sobre `idx_exemplares`: se os N vizinhos mais próximos concordam na mesma
folha com margem alta (limiares no `pipeline.yaml`, calibrados no doc 05), resolver
sem chamar o LLM. Esperado: ~70% do volume. Logar sempre por qual estágio o caso
foi resolvido.
