# 05 — Roteamento por Confiança, Avaliação e Feedback

> **Contexto**: o sistema opera como **classificação seletiva com opção de
> rejeição**: numa curva risco-cobertura, define-se o SLA (ex.: auto-classificar
> 75% do volume com ≥ 95% de acurácia em Tema; rotear o restante). Este doc define
> os sinais de roteamento, as métricas e o golden set de regressão.

## 1. Decisão final por caso: AUTO | REVISAO_HUMANA | REQUER_CONSULTA_SISTEMA

A decisão combina sinais **independentes** (autoconfiança de LLM sozinha é mal
calibrada). Implementar em `src/postprocess/routing.py`; limiares em
`config/pipeline.yaml`, calibrados em validação e recalibrados mensalmente.

| Sinal | Definição | Uso |
|---|---|---|
| Margem de retrieval | Diferença de score entre top-1 e top-2 **quando pertencem a Temas diferentes** | Preditor mais barato de ambiguidade; margem pequena ⇒ não-AUTO |
| Concordância entre sinais | kNN de exemplares vota no mesmo Tema que o LLM? Classificador auxiliar leve de Tema direto concorda? | Discordância ⇒ REVISAO_HUMANA |
| Classe de ambiguidade conhecida | Top candidatos caem num par ativo do `contrato_desambiguacao` sem features integradas | ⇒ REQUER_CONSULTA_SISTEMA **determinístico**, sem depender do modelo (auditável) |
| Status/abstenção do LLM | Saída estruturada do doc 04 | Respeitar abstenção; nunca "forçar" um AUTO por cima |
| Confiança autodeclarada | Campo `confianca` | Sinal fraco, apenas compõe |
| Conformal prediction | Conjunto de predição calibrado com garantia estatística de cobertura (ex.: 95%) no nível de Tema | Cardinalidade 1 ⇒ elegível a AUTO; > 1 ⇒ revisão/consulta. **Recomendado**: garantia formal defensável perante auditoria/BACEN |

Ordem de aplicação: (1) contrato de desambiguação (determinístico) → (2) abstenção
do LLM → (3) conformal/margem/concordância → (4) default AUTO somente se todos os
sinais passam.

## 2. Pós-processamento determinístico

`id_folha` → join com `taxonomia_canonica` → (familia, produto, assunto,
gestor_nivel_um, tema_classificacao). Único caminho de derivação de Gestor/Tema
em todo o sistema.

## 3. Avaliação — sempre em 4 níveis

Job `notebooks/eval_pipeline.py`, rodado a cada mudança relevante:

1. **Família** (= Gestor Nível Um): acurácia + macro-F1
2. **Produto**: acurácia + macro-F1
3. **Folha exata (id_folha)**: acurácia + macro-F1
4. **Tema**: acurácia + **macro-F1** (essencial pela cauda longa das ~3.000
   combinações — micro médio esconde classes raras)

Adicionais obrigatórios:
- **Curva risco-cobertura** (acurácia dos AUTO × % de volume AUTO) — é onde o SLA
  é definido e monitorado.
- **Análise por classe de ambiguidade**: para os pares do contrato, medir taxa de
  roteamento correto para REQUER_CONSULTA_SISTEMA (ali, "acertar o rótulo" não é
  a métrica — abster-se corretamente é).
- **recall@K do retrieval** (doc 03 §6) — teto do sistema.
- Não penalizar o irrecuperável: casos de classe ambígua têm como resposta
  esperada o conjunto + abstenção, não o rótulo que o humano só obteve com dados
  de sistema.

## 3b. MLflow Tracking — obrigatório para toda avaliação

Toda execução de avaliação (eval_pipeline, eval_recall, golden set) é um **run do
MLflow** no experimento definido em `config/pipeline.yaml` (`mlflow.experimento`).
Nada de métrica solta em print/notebook sem registro.

Por run, logar:
- **Params**: `versao_taxonomia`, versão do template de prompt, endpoints usados,
  snapshot dos limiares de roteamento, K/pesos do retrieval, hash/commit do código.
- **Metrics**: acurácia e macro-F1 nos 4 níveis (familia, produto, folha, tema),
  `recall_at_k`, `cobertura_auto`, `acuracia_tema_auto`, taxa de abstenção correta
  nos pares ambíguos, taxa de aprovação do golden set.
- **Artifacts**: matriz de confusão (nível Tema), curva risco-cobertura,
  JSONL de erros do golden set (casos que falharam, para diagnóstico).

Regras:
- Mudança só é promovida (merge/limiar novo/template novo) após **comparação de
  runs no MLflow** contra o baseline vigente — o run de referência fica taggeado
  (`tag: baseline=true`).
- O job do golden set falha (exit != 0) se qualquer caso regride vs. o baseline,
  e o run fica registrado mesmo em falha (é o histórico de regressões).
- Modelos/prompts promovidos referenciam o `run_id` da avaliação que os aprovou —
  rastreabilidade completa entre "o que está em produção" e "a evidência de que
  funciona".

## 4. Golden set de regressão (`tests/golden_set/`)

- 300–500 casos fixos e representativos: fáceis por família, cauda longa,
  **pares ambíguos com resposta esperada REQUER_CONSULTA_SISTEMA**, casos com PII
  para testar mascaramento, textos curtos/ruidosos.
- Formato: JSONL com `{texto, saida_esperada}` onde `saida_esperada` cobre status,
  id_folha (ou null), candidatos_plausiveis e dados_faltantes.
- **Rodar automaticamente sempre que qualquer configuração mudar** — INSERT no
  feature_registry, nova versão de taxonomia, novo template de prompt, novo limiar.
  Como quase tudo virou dado editável, o risco passa a ser degradar o sistema com
  um UPDATE inocente; o golden set no CI/job é o cinto de segurança.

## 5. Loop de feedback

1. Toda revisão humana (correção ou confirmação) é gravada com o par
   (texto_mascarado, saída_final) e origem `revisao_humana`.
2. Após verificação de qualidade + carência (`data_carencia_fim`), vira exemplar
   novo em `exemplares_rotulados` → reindexação incremental do `idx_exemplares`.
3. Mensalmente: recalibrar limiares (incl. conformal) e regenerar a matriz de
   confusão no nível de Tema → descobrir **novas** classes de ambiguidade →
   novas linhas no `contrato_desambiguacao` + features candidatas no
   `feature_registry` (priorizadas por `volume_estimado_mensal`).
4. Quando uma feature for integrada (`integrada_online = true`): medir no golden
   set e na produção a migração dos casos do par correspondente de
   REQUER_CONSULTA_SISTEMA para AUTO — é o ROI mensurável de cada integração.

## 6. Variáveis sintéticas inferíveis só do texto (features auxiliares)

Úteis para o classificador auxiliar, roteamento e priorização — implementar como
colunas derivadas no enriquecimento: entidades de produto via NER (cartão,
consignado, financiamento, conta), valores monetários e datas citados, verbos de
intenção (contestar, cancelar, renegociar, ressarcir), menção a órgãos externos
(BACEN, Procon, Justiça — altera criticidade), sentimento/urgência, referência a
protocolo anterior. Metadados sem integração de sistema: canal de entrada,
timestamp, histórico de manifestações do cliente na própria Ouvidoria. Desenhar o
schema com os campos futuros de sistema como *nullable* — o pipeline não muda
quando eles chegarem; só a taxa de resolução automática sobe.
