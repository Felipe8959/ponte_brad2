# references/

Espelho dos documentos de `docs/` do repositório. A skill vive fora do Git folder,
em /Users/{seu_usuario}/.assistant/skills/classificador-ouvidoria/ — após atualizar
o repo, sincronize:

    cp -r <repo>/docs/*.md <skills>/classificador-ouvidoria/references/

Mantenha sincronizado quando os docs mudarem (ou automatize com um job simples).
