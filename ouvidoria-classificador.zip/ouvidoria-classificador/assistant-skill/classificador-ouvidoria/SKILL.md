---
name: classificador-ouvidoria
description: >
  Arquitetura e regras do classificador de manifestações da Ouvidoria bancária
  (taxonomia Família > Produto > Assunto, ~3.000 folhas; Gestor Nível Um e Tema
  derivados por lookup; Qwen3-Embedding + Llama 8B no Model Serving; Vector Search;
  structured outputs). Use esta skill SEMPRE que a tarefa envolver: classificação
  de manifestações, taxonomia da Ouvidoria, id_folha, tema_classificacao, gestor
  nível um, feature_registry, contrato de desambiguação, retrieval/embeddings do
  projeto, prompt de inferência, roteamento AUTO/REVISAO/CONSULTA, golden set —
  mesmo que o pedido não cite a skill explicitamente.
---

# Classificador de Manifestações — Ouvidoria

Skill de desenvolvimento do pipeline de classificação. A fonte de verdade completa
está no repositório `ouvidoria-classificador` (Git folder do workspace); os mesmos
documentos estão espelhados em `references/` desta skill.

## Regras invioláveis (resumo — detalhe em references/01_arquitetura.md)

1. Prever somente `id_folha`; Gestor e Tema SEMPRE por lookup em `taxonomia_canonica`.
2. Classificação é seleção via enum (structured outputs), nunca geração de texto livre.
3. Nomes físicos de colunas só em `src/io/loader.py` via `config/columns.{env}.yaml`.
4. Features externas só via tabela `feature_registry`; enum de `dados_faltantes`
   gerado em runtime (`WHERE ativa`). Adicionar feature = 1 INSERT, zero deploy.
5. O modelo pode se abster: status AUTO | REQUER_CONSULTA_SISTEMA | REVISAO_HUMANA.
6. Mascarar PII antes de qualquer embedding ou chamada a LLM.
7. Temperatura 0 + `response_format: json_schema` com enum restrito à shortlist.
8. Toda mudança (código OU config em tabela) roda o golden set antes de concluir.

## Workflow por tipo de tarefa

| Tarefa pedida | Consultar | Observações |
|---|---|---|
| Criar/alterar tabelas de config, loader, YAML de colunas | `references/02_dados_config.md` | DDLs prontos; validar constraints nos testes |
| Embeddings, índices Vector Search, busca, recall | `references/03_retrieval.md` | Qwen3 é instruction-aware: instrução só na query; gate recall@K ≥ 98% |
| Prompt, JSON Schema, few-shot, chamada ao LLM, batch | `references/04_inferencia.md` | Template em `prompts/inferencia_v1.j2`; shortlist 8–12 p/ Llama 8B |
| Roteamento, limiares, métricas, golden set, feedback | `references/05_roteamento_eval.md` | Avaliar sempre em 4 níveis; macro-F1 em Tema |
| Dúvida de arquitetura / decisão nova | `references/01_arquitetura.md` | Se a decisão contradiz uma regra inviolável, PARE e pergunte ao usuário |

## Passos padrão ao executar qualquer tarefa do projeto

1. Ler `AGENTS.md` do repo (ou o resumo acima) e o reference do tópico.
2. Verificar em `STATUS.md` o estado atual e a fase em andamento (1–6).
3. Implementar usando os artefatos prontos (`config/*.yaml`, `prompts/*.j2`) como
   base — copiar estrutura, não reinventar.
4. Criar/atualizar testes; rodar o golden set se a mudança afeta comportamento.
5. Atualizar `STATUS.md` com o que foi feito, decisões e pendências.

## Anti-padrões (recusar e corrigir se encontrar no código)

- Prever Tema ou Gestor diretamente do texto em produção (só é permitido como
  sinal auxiliar de concordância no roteamento).
- Nome físico de coluna/tabela fora do loader.
- Lista de features de sistema hardcoded em prompt, schema ou código.
- Prompt montado por concatenação de strings fora do template Jinja2.
- Forçar o modelo a escolher entre candidatos de Temas diferentes quando o par
  está no `contrato_desambiguacao` sem features integradas.
